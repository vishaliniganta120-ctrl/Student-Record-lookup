const db = require("../config/db");

async function findAdmin(login) {
  const [rows] = await db.execute(
    "SELECT id, username, email, password_hash FROM admins WHERE username = ? OR email = ? LIMIT 1",
    [login, login]
  );
  return rows[0];
}

module.exports = { findAdmin };
