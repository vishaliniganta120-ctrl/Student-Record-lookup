const db = require("../config/db");

function buildStudentWhere(filters = {}) {
  const conditions = [];
  const params = [];
  const search = filters.search || "";

  if (search) {
    conditions.push(`(
      student_id LIKE ? OR full_name LIKE ? OR department LIKE ?
      OR email LIKE ? OR phone_number LIKE ?
    )`);
    const value = `%${search}%`;
    params.push(value, value, value, value, value);
  }
  if (filters.studentId) {
    conditions.push("student_id LIKE ?");
    params.push(`%${filters.studentId}%`);
  }
  if (filters.name) {
    conditions.push("full_name LIKE ?");
    params.push(`%${filters.name}%`);
  }
  if (filters.department) {
    conditions.push("department = ?");
    params.push(filters.department);
  }
  if (filters.year) {
    conditions.push("year = ?");
    params.push(Number(filters.year));
  }
  if (filters.section) {
    conditions.push("section = ?");
    params.push(filters.section);
  }
  if (filters.email) {
    conditions.push("email LIKE ?");
    params.push(`%${filters.email}%`);
  }
  if (filters.phone) {
    conditions.push("phone_number LIKE ?");
    params.push(`%${filters.phone}%`);
  }

  return {
    where: conditions.length ? `WHERE ${conditions.join(" AND ")}` : "",
    params
  };
}

const allowedSorts = {
  student_id: "student_id",
  full_name: "full_name",
  department: "department",
  year: "year",
  section: "section",
  email: "email",
  cgpa: "cgpa",
  attendance: "attendance",
  backlogs: "backlogs"
};

async function getAllStudents(filters = {}) {
  const { where, params } = buildStudentWhere(filters);
  const sort = allowedSorts[filters.sort] || "full_name";
  const direction = String(filters.order).toUpperCase() === "DESC" ? "DESC" : "ASC";

  const page = Math.max(Number(filters.page) || 1, 1);
  const limit = Math.min(Math.max(Number(filters.limit) || 10, 1), 100);
  const offset = (page - 1) * limit;

  const [countRows] = await db.execute(
    `SELECT COUNT(*) AS total FROM students ${where}`,
    params
  );

  const [rows] = await db.execute(
    `SELECT student_id, full_name, date_of_birth, gender, email, phone_number,
            department, year, section, cgpa, address, attendance, backlogs,
            created_at, updated_at
     FROM students ${where}
     ORDER BY ${sort} ${direction}, full_name ASC
     LIMIT ? OFFSET ?`,
    [...params, limit, offset]
  );

  const total = Number(countRows[0].total);
  return {
    rows,
    pagination: {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit)
    }
  };
}

async function getStudentById(studentId) {
  const [rows] = await db.execute(
    "SELECT * FROM students WHERE student_id = ?",
    [studentId]
  );
  return rows[0];
}

async function createStudent(student) {
  const sql = `
    INSERT INTO students
    (student_id, full_name, date_of_birth, gender, email, phone_number,
     department, year, section, cgpa, address, attendance, backlogs)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;
  const values = [
    student.student_id, student.full_name, student.date_of_birth,
    student.gender, student.email, student.phone_number, student.department,
    student.year, student.section, student.cgpa, student.address,
    student.attendance, student.backlogs
  ];
  await db.execute(sql, values);
  return getStudentById(student.student_id);
}

async function updateStudent(studentId, student) {
  const sql = `
    UPDATE students SET
      full_name = ?, date_of_birth = ?, gender = ?, email = ?,
      phone_number = ?, department = ?, year = ?, section = ?,
      cgpa = ?, address = ?, attendance = ?, backlogs = ?
    WHERE student_id = ?
  `;
  const values = [
    student.full_name, student.date_of_birth, student.gender,
    student.email, student.phone_number, student.department,
    student.year, student.section, student.cgpa, student.address,
    student.attendance, student.backlogs, studentId
  ];
  const [result] = await db.execute(sql, values);
  if (result.affectedRows === 0) return null;
  return getStudentById(studentId);
}

async function deleteStudent(studentId) {
  const [result] = await db.execute(
    "DELETE FROM students WHERE student_id = ?",
    [studentId]
  );
  return result.affectedRows > 0;
}

async function getDepartmentStats() {
  const [rows] = await db.execute(`
    SELECT
      department,
      COUNT(*) AS totalStudents,
      ROUND(COALESCE(AVG(cgpa), 0), 2) AS averageCgpa,
      ROUND(COALESCE(AVG(attendance), 0), 2) AS averageAttendance,
      SUM(CASE WHEN backlogs > 0 THEN 1 ELSE 0 END) AS studentsWithBacklogs
    FROM students
    GROUP BY department
    ORDER BY department ASC
  `);

  const [yearRows] = await db.execute(`
    SELECT department, year, COUNT(*) AS studentCount
    FROM students
    GROUP BY department, year
    ORDER BY department ASC, year ASC
  `);

  const yearMap = {};
  for (const row of yearRows) {
    if (!yearMap[row.department]) yearMap[row.department] = {};
    yearMap[row.department][row.year] = Number(row.studentCount);
  }

  return rows.map(row => ({
    department: row.department,
    totalStudents: Number(row.totalStudents),
    averageCgpa: Number(row.averageCgpa),
    averageAttendance: Number(row.averageAttendance),
    studentsWithBacklogs: Number(row.studentsWithBacklogs || 0),
    yearWiseCount: yearMap[row.department] || {}
  }));
}

async function getStudentsByDepartment(department, filters = {}) {
  return getAllStudents({ ...filters, department });
}

async function getDashboardStats() {
  const [summaryRows] = await db.execute(`
    SELECT
      COUNT(*) AS totalStudents,
      COUNT(DISTINCT department) AS departments,
      ROUND(COALESCE(AVG(cgpa), 0), 2) AS averageCgpa,
      SUM(CASE WHEN backlogs > 0 THEN 1 ELSE 0 END) AS studentsWithBacklogs,
      ROUND(COALESCE(AVG(attendance), 0), 2) AS averageAttendance
    FROM students
  `);

  const departmentStats = await getDepartmentStats();
  const [performanceRows] = await db.execute(`
    SELECT
      ROUND(COALESCE(AVG(cgpa), 0), 2) AS averageCgpa,
      ROUND(COALESCE(AVG(attendance), 0), 2) AS averageAttendance
    FROM students
  `);

  return {
    summary: summaryRows[0],
    departmentDistribution: departmentStats.map(d => ({
      department: d.department,
      count: d.totalStudents
    })),
    performance: performanceRows[0]
  };
}

module.exports = {
  getAllStudents,
  getStudentById,
  getStudentsByDepartment,
  createStudent,
  updateStudent,
  deleteStudent,
  getDepartmentStats,
  getDashboardStats
};
