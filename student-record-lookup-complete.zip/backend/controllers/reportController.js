const db = require("../config/db");

async function summary(req, res) {
  try {
    const [rows] = await db.execute(`
      SELECT COUNT(*) AS totalStudents,
             COUNT(DISTINCT department) AS totalDepartments,
             ROUND(COALESCE(AVG(cgpa),0),2) AS averageCgpa,
             ROUND(COALESCE(AVG(attendance),0),2) AS averageAttendance,
             SUM(CASE WHEN backlogs > 0 THEN 1 ELSE 0 END) AS studentsWithBacklogs
      FROM students
    `);
    res.json({ success: true, data: rows[0] });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Could not load report summary." });
  }
}

async function department(req, res) {
  try {
    const [rows] = await db.execute(`
      SELECT department,
             COUNT(*) AS totalStudents,
             ROUND(AVG(cgpa),2) AS averageCgpa,
             ROUND(AVG(attendance),2) AS averageAttendance,
             SUM(CASE WHEN backlogs > 0 THEN 1 ELSE 0 END) AS studentsWithBacklogs
      FROM students
      GROUP BY department
      ORDER BY department
    `);
    res.json({ success: true, data: rows });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Could not load department report." });
  }
}

async function year(req, res) {
  try {
    const [rows] = await db.execute(`
      SELECT year, COUNT(*) AS studentCount
      FROM students
      GROUP BY year
      ORDER BY year
    `);
    res.json({ success: true, data: rows });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Could not load year report." });
  }
}

module.exports = { summary, department, year };
