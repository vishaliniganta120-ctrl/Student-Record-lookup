const bcrypt = require("bcryptjs");
const { findAdmin } = require("../models/adminModel");

async function login(req, res) {
  try {
    const { login, password } = req.body;

    if (!login || !password) {
      return res.status(400).json({
        success: false,
        message: "Username/email and password are required."
      });
    }

    const admin = await findAdmin(login);
    if (!admin) {
      return res.status(401).json({
        success: false,
        message: "Invalid login details."
      });
    }

    const validPassword = await bcrypt.compare(password, admin.password_hash);
    if (!validPassword) {
      return res.status(401).json({
        success: false,
        message: "Invalid login details."
      });
    }

    req.session.admin = {
      id: admin.id,
      username: admin.username,
      email: admin.email
    };

    res.json({
      success: true,
      message: "Login successful.",
      admin: req.session.admin
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Login failed." });
  }
}

function logout(req, res) {
  req.session.destroy(() => {
    res.json({ success: true, message: "Logged out successfully." });
  });
}

function me(req, res) {
  res.json({
    success: true,
    authenticated: Boolean(req.session.admin),
    admin: req.session.admin || null
  });
}

module.exports = { login, logout, me };
