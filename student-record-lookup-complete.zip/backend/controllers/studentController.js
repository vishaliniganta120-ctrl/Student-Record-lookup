const studentModel = require("../models/studentModel");

function validateStudent(data, isUpdate = false) {
  const errors = [];
  const required = [
    "full_name", "date_of_birth", "gender", "email", "phone_number",
    "department", "year", "section", "cgpa", "address", "attendance", "backlogs"
  ];

  if (!isUpdate && !data.student_id) errors.push("Student ID is required.");
  required.forEach(field => {
    if (data[field] === undefined || data[field] === null || String(data[field]).trim() === "") {
      errors.push(`${field.replaceAll("_", " ")} is required.`);
    }
  });

  if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.push("Enter a valid email address.");
  }
  if (data.phone_number && !/^\d{10,15}$/.test(String(data.phone_number))) {
    errors.push("Phone number must contain 10 to 15 digits.");
  }
  if (data.year !== undefined && (Number(data.year) < 1 || Number(data.year) > 4)) {
    errors.push("Year must be between 1 and 4.");
  }
  if (data.cgpa !== undefined && (Number(data.cgpa) < 0 || Number(data.cgpa) > 10)) {
    errors.push("CGPA must be between 0 and 10.");
  }
  if (data.attendance !== undefined && (Number(data.attendance) < 0 || Number(data.attendance) > 100)) {
    errors.push("Attendance must be between 0 and 100.");
  }
  if (data.backlogs !== undefined && Number(data.backlogs) < 0) {
    errors.push("Backlogs cannot be negative.");
  }

  return errors;
}

async function listStudents(req, res) {
  try {
    const result = await studentModel.getAllStudents(req.query);
    res.json({ success: true, data: result.rows, pagination: result.pagination });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Could not fetch students." });
  }
}

async function getStudent(req, res) {
  try {
    const student = await studentModel.getStudentById(req.params.id);
    if (!student) {
      return res.status(404).json({ success: false, message: "Student not found." });
    }
    res.json({ success: true, data: student });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Could not fetch student." });
  }
}

async function getDepartmentStudents(req, res) {
  try {
    const department = decodeURIComponent(req.params.department);
    const result = await studentModel.getStudentsByDepartment(department, req.query);
    res.json({
      success: true,
      department,
      data: result.rows,
      pagination: result.pagination
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Could not fetch department students." });
  }
}

async function createStudent(req, res) {
  try {
    const errors = validateStudent(req.body);
    if (errors.length) {
      return res.status(400).json({ success: false, message: errors.join(" ") });
    }

    const existingId = await studentModel.getStudentById(req.body.student_id);
    if (existingId) {
      return res.status(409).json({
        success: false,
        message: "A student with this Student ID already exists."
      });
    }

    const student = await studentModel.createStudent(req.body);
    res.status(201).json({ success: true, message: "Student added successfully.", data: student });
  } catch (error) {
    console.error(error);
    if (error.code === "ER_DUP_ENTRY") {
      return res.status(409).json({ success: false, message: "Student ID or email already exists." });
    }
    res.status(500).json({ success: false, message: "Could not add student." });
  }
}

async function updateStudent(req, res) {
  try {
    const errors = validateStudent(req.body, true);
    if (errors.length) {
      return res.status(400).json({ success: false, message: errors.join(" ") });
    }

    const student = await studentModel.updateStudent(req.params.id, req.body);
    if (!student) {
      return res.status(404).json({ success: false, message: "Student not found." });
    }

    res.json({ success: true, message: "Student updated successfully.", data: student });
  } catch (error) {
    console.error(error);
    if (error.code === "ER_DUP_ENTRY") {
      return res.status(409).json({ success: false, message: "The email is already used by another student." });
    }
    res.status(500).json({ success: false, message: "Could not update student." });
  }
}

async function deleteStudent(req, res) {
  try {
    const deleted = await studentModel.deleteStudent(req.params.id);
    if (!deleted) {
      return res.status(404).json({ success: false, message: "Student not found." });
    }
    res.json({ success: true, message: "Student deleted successfully." });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Could not delete student." });
  }
}

async function departmentStats(req, res) {
  try {
    const stats = await studentModel.getDepartmentStats();
    res.json({ success: true, data: stats });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Could not load department statistics." });
  }
}

async function dashboard(req, res) {
  try {
    const stats = await studentModel.getDashboardStats();
    res.json({ success: true, data: stats });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Could not load dashboard." });
  }
}

module.exports = {
  listStudents,
  getStudent,
  getDepartmentStudents,
  createStudent,
  updateStudent,
  deleteStudent,
  departmentStats,
  dashboard
};
