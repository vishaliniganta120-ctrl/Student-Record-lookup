const express = require("express");
const { requireAuth } = require("../middleware/authMiddleware");
const { summary, department, year } = require("../controllers/reportController");

const router = express.Router();
router.use(requireAuth);
router.get("/summary", summary);
router.get("/department", department);
router.get("/year", year);

module.exports = router;
