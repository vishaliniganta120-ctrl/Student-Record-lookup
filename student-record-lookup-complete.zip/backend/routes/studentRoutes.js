const express = require("express");
const { requireAuth } = require("../middleware/authMiddleware");
const {
  listStudents,
  getStudent,
  getDepartmentStudents,
  createStudent,
  updateStudent,
  deleteStudent,
  departmentStats,
  dashboard
} = require("../controllers/studentController");

const router = express.Router();
router.use(requireAuth);

router.get("/dashboard", dashboard);
router.get("/search", listStudents);
router.get("/departments/stats", departmentStats);
router.get("/department/:department", getDepartmentStudents);
router.get("/", listStudents);
router.get("/:id", getStudent);
router.post("/", createStudent);
router.put("/:id", updateStudent);
router.delete("/:id", deleteStudent);

module.exports = router;
