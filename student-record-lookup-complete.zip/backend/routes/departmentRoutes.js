const express = require("express");
const { requireAuth } = require("../middleware/authMiddleware");
const { departmentStats, getDepartmentStudents } = require("../controllers/studentController");

const router = express.Router();
router.use(requireAuth);

router.get("/", async (req, res) => {
  try {
    const stats = await require("../models/studentModel").getDepartmentStats();
    res.json({ success: true, data: stats.map(x => x.department) });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Could not load departments." });
  }
});
router.get("/stats", departmentStats);
router.get("/:department/students", getDepartmentStudents);

module.exports = router;
