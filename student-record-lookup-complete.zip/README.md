# Student Record Lookup System

A complete college hackathon project for authorized admins to manage, search, filter, group and report student academic records.

## Features

- Admin login/logout with session authentication and bcrypt password verification
- Protected student-management APIs
- Dashboard statistics and charts
- All Students table
- Search by Student ID, name, department, email and phone
- Department, year and section filters
- Sorting and server-side pagination
- View, add, edit and delete student records
- Delete confirmation
- Dynamic department cards generated from MySQL
- Department-wise student lists
- Department statistics: count, average CGPA, average attendance, backlog count
- Department/year reports
- Responsive mobile-friendly UI
- Parameterized SQL queries
- Validation and user-friendly errors
- 20 fictional sample students across multiple departments

## Technology

HTML5, CSS3, JavaScript, Node.js, Express.js, MySQL, Chart.js.

## Project Structure

```text
student-record-lookup/
├── frontend/
│   ├── index.html
│   ├── app.js
│   └── style.css
├── backend/
│   ├── server.js
│   ├── config/db.js
│   ├── controllers/
│   │   ├── authController.js
│   │   ├── reportController.js
│   │   └── studentController.js
│   ├── middleware/authMiddleware.js
│   ├── models/
│   │   ├── adminModel.js
│   │   └── studentModel.js
│   └── routes/
│       ├── authRoutes.js
│       ├── departmentRoutes.js
│       ├── reportRoutes.js
│       └── studentRoutes.js
├── database/schema.sql
├── public/.gitkeep
├── .env.example
├── package.json
└── README.md
```

The frontend is intentionally a simple single-page dashboard instead of requiring a frontend framework. Its pages are rendered as dashboard sections, which keeps the project easy for four students to explain.

## Requirements

- Node.js 18+
- MySQL 8+
- VS Code or another code editor

## Setup

1. Create the database:

```bash
mysql -u root -p < database/schema.sql
```

Or execute `database/schema.sql` in MySQL Workbench.

2. Copy `.env.example` to `.env` and set your MySQL password and session secret.

3. Install packages:

```bash
npm install
```

4. Run:

```bash
npm start
```

For development:

```bash
npm run dev
```

5. Open `http://localhost:5000`.

## Environment

```env
PORT=5000
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=student_record_db
SESSION_SECRET=change_this_to_a_long_random_secret
```

Never put database credentials in frontend JavaScript.

## Demo login

```text
Username: admin
Password: password
Email: admin@college.edu
```

Change this before any real deployment.

## REST API

Authentication:

```text
POST /api/auth/login
POST /api/auth/logout
GET  /api/auth/me
```

Students (protected):

```text
GET    /api/students
GET    /api/students/:id
GET    /api/students/search
POST   /api/students
PUT    /api/students/:id
DELETE /api/students/:id
```

Student query examples:

```text
/api/students?search=Anjali
/api/students?department=CSE&year=2&section=A
/api/students?sort=cgpa&order=DESC&page=1&limit=10
```

Departments (protected):

```text
GET /api/departments
GET /api/departments/stats
GET /api/departments/:department/students
```

Reports (protected):

```text
GET /api/reports/summary
GET /api/reports/department
GET /api/reports/year
```

## Database design

There is one `students` table. The department is stored in the `department` column. There is deliberately no `cse_students`, `ece_students`, etc. table.

When a student changes from CSE to ECE, only the `department` value changes. Every department card, department list, search and report reads that same value from MySQL, so the student automatically moves between groups.

## Four-member team division

### Member 1 — Frontend

- Dashboard UI
- All Students page
- Departments page
- Add/edit student forms
- Responsive styling

### Member 2 — Backend

- Express server
- REST APIs
- Authentication
- Validation and error handling

### Member 3 — Database

- MySQL schema
- Parameterized queries
- Constraints/indexes
- Sample data
- Statistics/report queries

### Member 4 — Integration & Testing

- Connect frontend to APIs
- Test CRUD/search/filter/pagination
- Test authentication and errors
- Documentation and hackathon presentation

## Testing checklist

- [ ] Login with valid credentials
- [ ] Invalid login shows an error
- [ ] Dashboard loads live statistics
- [ ] All Students loads records
- [ ] Search works by ID/name/email/phone
- [ ] Department/year/section filters work
- [ ] Sorting works both directions
- [ ] Pagination works
- [ ] View opens full profile
- [ ] Add creates a record
- [ ] Duplicate Student ID is rejected
- [ ] Edit changes the record
- [ ] Changing department moves the student automatically
- [ ] Delete asks for confirmation
- [ ] Delete updates lists and statistics
- [ ] Department cards are database-generated
- [ ] Reports load live department/year statistics
- [ ] Mobile layout works

## Hackathon demo flow

1. Login as admin.
2. Show the dashboard and live statistics.
3. Open All Students and demonstrate search, filters, sorting and pagination.
4. Open Departments and explain that cards are generated with SQL `GROUP BY department`.
5. Click CSE and show only CSE students.
6. Edit one student from CSE to ECE.
7. Return to Departments and show that the same student is now under ECE without manually updating a list.
8. Add a new student under a new department value and show that the department appears automatically.
9. Delete a student and show dashboard/report values update.
10. Open Reports and show department and year statistics.

## Common judge questions

**Why one students table instead of one table per department?**

A single normalized table avoids duplicated schemas and makes adding a new department automatic. The department column is enough to group and filter records.

**How is department grouping dynamic?**

The backend runs aggregate SQL with `GROUP BY department`. The frontend renders the returned rows; it does not contain hardcoded student lists.

**How do you prevent SQL injection?**

User values are passed as parameters to MySQL `execute()` calls. Sort fields are restricted through an allow-list.

**What happens when the department changes?**

The student's `department` column is updated. Department queries read the current value, so the student immediately belongs to the new department.

**How are passwords protected?**

The admin password is stored as a bcrypt hash and verified with bcrypt during login. Sessions protect admin-only APIs.

**What can be added later?**

Role-based access, PDF/Excel exports, audit logs, faculty accounts, password reset, email alerts, and cloud deployment.
