let departmentChart;
let performanceChart;
let editingStudentId = null;
let allPage = 1;
const pageSize = 10;
let currentDepartment = "";

const $ = id => document.getElementById(id);

async function api(url, options = {}) {
  const response = await fetch(url, {
    credentials: "include",
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({ success: false, message: "Invalid server response." }));
  if (!response.ok) {
    if (response.status === 401) showLogin();
    throw new Error(data.message || "Something went wrong.");
  }
  return data;
}

function showToast(message, type = "success") {
  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.textContent = message;
  $("toast-container").appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}
function showLogin() { $("login-page").classList.remove("hidden"); $("app").classList.add("hidden"); }
function showApp(admin) { $("login-page").classList.add("hidden"); $("app").classList.remove("hidden"); $("admin-name").textContent = admin.username; }

function switchPage(page) {
  document.querySelectorAll(".page").forEach(p => p.classList.remove("active-page"));
  document.querySelectorAll(".nav-item").forEach(b => b.classList.remove("active"));
  const target = $(`page-${page}`);
  if (!target) return;
  target.classList.add("active-page");
  const nav = document.querySelector(`.nav-item[data-page="${page}"]`);
  if (nav) nav.classList.add("active");
  const titles = {
    dashboard: ["OVERVIEW", "Dashboard"],
    "all-students": ["RECORDS", "All Students"],
    departments: ["ACADEMICS", "Departments"],
    "add-student": ["MANAGEMENT", editingStudentId ? "Edit Student" : "Add Student"],
    search: ["LOOKUP", "Search Students"],
    reports: ["ANALYTICS", "Reports"]
  };
  $("page-kicker").textContent = titles[page][0];
  $("page-title").textContent = titles[page][1];
  if (page === "dashboard") loadDashboard();
  if (page === "all-students") loadAllStudents();
  if (page === "departments") loadDepartments();
  if (page === "add-student") loadDepartmentOptions("department", editingStudentId ? $("department").value : "");
  if (page === "search") loadDepartmentOptions("search-department", $("search-department").value);
  if (page === "reports") loadReports();
  document.querySelector(".sidebar").classList.remove("open");
}

async function checkSession() {
  try {
    const result = await api("/api/auth/me");
    if (result.authenticated) { showApp(result.admin); switchPage("dashboard"); }
    else showLogin();
  } catch { showLogin(); }
}

async function loadDashboard() {
  try {
    const result = await api("/api/students/dashboard");
    const data = result.data;
    $("total-students").textContent = data.summary.totalStudents;
    $("total-departments").textContent = data.summary.departments;
    $("avg-cgpa").textContent = data.summary.averageCgpa;
    $("backlog-students").textContent = data.summary.studentsWithBacklogs;
    $("avg-attendance").textContent = `${data.summary.averageAttendance}%`;
    if (departmentChart) departmentChart.destroy();
    if (performanceChart) performanceChart.destroy();
    departmentChart = new Chart($("department-chart"), {
      type: "doughnut",
      data: { labels: data.departmentDistribution.map(x => x.department), datasets: [{ data: data.departmentDistribution.map(x => x.count) }] },
      options: { responsive: true, plugins: { legend: { position: "bottom" } } }
    });
    performanceChart = new Chart($("performance-chart"), {
      type: "bar",
      data: { labels: ["Average CGPA", "Average Attendance"], datasets: [{ label: "Value", data: [data.performance.averageCgpa, data.performance.averageAttendance] }] },
      options: { responsive: true, scales: { y: { beginAtZero: true, max: 100 } }, plugins: { legend: { display: false } } }
    });
  } catch (error) { showToast(error.message, "error"); }
}

async function getDepartmentStats() {
  const result = await api("/api/departments/stats");
  return result.data;
}

async function loadDepartmentOptions(selectId, selected = "") {
  try {
    const stats = await getDepartmentStats();
    const select = $(selectId);
    if (!select) return;
    const first = selectId === "department" ? "<option value=\"\">Select Department</option>" : "<option value=\"\">All Departments</option>";
    select.innerHTML = first + stats.map(d => `<option value="${escapeAttr(d.department)}">${escapeHtml(d.department)}</option>`).join("");
    if (selected && stats.some(d => d.department === selected)) select.value = selected;
  } catch (error) { showToast(error.message, "error"); }
}

async function loadAllStudents() {
  $("all-students-table").innerHTML = `<div class="loading">Loading all student records...</div>`;
  try {
    await loadDepartmentOptions("all-department", $("all-department").value);
    const params = new URLSearchParams({ page: allPage, limit: pageSize });
    const values = {
      search: $("all-search").value.trim(), department: $("all-department").value,
      year: $("all-year").value, section: $("all-section").value,
      sort: $("all-sort").value, order: $("all-order").value
    };
    Object.entries(values).forEach(([k, v]) => { if (v) params.set(k, v); });
    const result = await api(`/api/students?${params}`);
    $("all-students-table").innerHTML = studentTable(result.data);
    renderPagination(result.pagination);
    await loadSectionsForFilter();
  } catch (error) {
    $("all-students-table").innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`;
    $("all-pagination").innerHTML = "";
  }
}

async function loadSectionsForFilter() {
  try {
    const params = new URLSearchParams();
    const department = $("all-department").value;
    const year = $("all-year").value;
    if (department) params.set("department", department);
    if (year) params.set("year", year);
    params.set("limit", "100");
    const result = await api(`/api/students?${params}`);
    const sections = [...new Set(result.data.map(s => s.section))].sort();
    const select = $("all-section");
    const current = select.value;
    select.innerHTML = `<option value="">All Sections</option>` + sections.map(x => `<option value="${escapeAttr(x)}">Section ${escapeHtml(x)}</option>`).join("");
    if (sections.includes(current)) select.value = current;
  } catch {}
}

function renderPagination(p) {
  if (!p || p.totalPages <= 1) { $("all-pagination").innerHTML = p ? `<span>${p.total} record(s)</span>` : ""; return; }
  let html = `<span>${p.total} record(s) · Page ${p.page} of ${p.totalPages}</span><div>`;
  html += `<button class="btn small secondary" ${p.page === 1 ? "disabled" : ""} onclick="changeAllPage(${p.page - 1})">Previous</button>`;
  for (let i = 1; i <= p.totalPages; i++) {
    if (i === 1 || i === p.totalPages || Math.abs(i - p.page) <= 2) {
      html += `<button class="btn small ${i === p.page ? "primary" : "secondary"}" onclick="changeAllPage(${i})">${i}</button>`;
    } else if (Math.abs(i - p.page) === 3) html += `<span>…</span>`;
  }
  html += `<button class="btn small secondary" ${p.page === p.totalPages ? "disabled" : ""} onclick="changeAllPage(${p.page + 1})">Next</button></div>`;
  $("all-pagination").innerHTML = html;
}
window.changeAllPage = page => { allPage = page; loadAllStudents(); };

function studentTable(students) {
  if (!students.length) return `<div class="empty-state">No student records found.</div>`;
  return `<div class="table-wrap"><table><thead><tr>
    <th>Student</th><th>Department</th><th>Year</th><th>Section</th><th>Email</th><th>Phone</th><th>CGPA</th><th>Attendance</th><th>Backlogs</th><th>Actions</th>
  </tr></thead><tbody>${students.map(s => `<tr>
    <td><strong>${escapeHtml(s.full_name)}</strong><br><small class="muted">${escapeHtml(s.student_id)}</small></td>
    <td>${escapeHtml(s.department)}</td><td>${s.year}</td><td>${escapeHtml(s.section)}</td>
    <td>${escapeHtml(s.email)}</td><td>${escapeHtml(s.phone_number)}</td><td>${s.cgpa}</td>
    <td><span class="badge ${Number(s.attendance) >= 75 ? "good" : "warn"}">${s.attendance}%</span></td>
    <td>${Number(s.backlogs) ? `<span class="badge warn">${s.backlogs}</span>` : `<span class="badge good">0</span>`}</td>
    <td><div class="actions"><button class="btn small secondary" onclick="viewStudent('${encodeURIComponent(s.student_id)}')">View</button><button class="btn small secondary" onclick="editStudent('${encodeURIComponent(s.student_id)}')">Edit</button><button class="btn small danger" onclick="deleteStudent('${encodeURIComponent(s.student_id)}')">Delete</button></div></td>
  </tr>`).join("")}</tbody></table></div>`;
}

async function loadDepartments() {
  $("department-cards").innerHTML = `<div class="loading">Loading departments...</div>`;
  try {
    const stats = await getDepartmentStats();
    $("department-cards").innerHTML = stats.length ? stats.map(d => `<button class="department-card" onclick="openDepartment('${encodeURIComponent(d.department)}')">
      <div class="department-icon">${escapeHtml(d.department.slice(0,2).toUpperCase())}</div>
      <div class="department-name">${escapeHtml(d.department)}</div>
      <div class="department-total">${d.totalStudents} <span>students</span></div>
      <div class="department-mini"><span>CGPA <strong>${d.averageCgpa}</strong></span><span>Attendance <strong>${d.averageAttendance}%</strong></span><span>Backlogs <strong>${d.studentsWithBacklogs}</strong></span></div>
    </button>`).join("") : `<div class="empty-state">No departments exist yet. Add a student to create the first department.</div>`;
    if (currentDepartment) await showDepartmentStudents(currentDepartment);
  } catch (error) { $("department-cards").innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`; }
}

window.openDepartment = async encoded => {
  currentDepartment = decodeURIComponent(encoded);
  await showDepartmentStudents(currentDepartment);
};

async function showDepartmentStudents(department) {
  $("selected-department-title").textContent = department;
  $("selected-department-subtitle").textContent = `Students currently registered under ${department}.`;
  $("department-students-list").innerHTML = `<div class="loading">Loading ${escapeHtml(department)} students...</div>`;
  try {
    const result = await api(`/api/students/department/${encodeURIComponent(department)}?limit=100`);
    $("department-students-list").innerHTML = studentTable(result.data);
  } catch (error) { $("department-students-list").innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`; }
}

async function loadReports() {
  try {
    const stats = await getDepartmentStats();
    const total = stats.reduce((a, d) => a + d.totalStudents, 0);
    const weightedCgpa = total ? stats.reduce((a,d) => a + d.averageCgpa * d.totalStudents, 0) / total : 0;
    const weightedAttendance = total ? stats.reduce((a,d) => a + d.averageAttendance * d.totalStudents, 0) / total : 0;
    $("report-total").textContent = total;
    $("report-cgpa").textContent = weightedCgpa.toFixed(2);
    $("report-attendance").textContent = `${weightedAttendance.toFixed(2)}%`;
    $("report-backlogs").textContent = stats.reduce((a,d)=>a+d.studentsWithBacklogs,0);
    $("report-departments").innerHTML = stats.length ? stats.map(d => `<div class="report-department"><div class="report-row"><span><strong>${escapeHtml(d.department)}</strong></span><strong>${d.totalStudents} students</strong></div><div class="year-counts">${Object.entries(d.yearWiseCount).map(([year,count])=>`<span>Year ${year}: ${count}</span>`).join("")}</div><div class="report-metrics"><span>CGPA <b>${d.averageCgpa}</b></span><span>Attendance <b>${d.averageAttendance}%</b></span><span>Backlogs <b>${d.studentsWithBacklogs}</b></span></div></div>`).join("") : `<div class="empty-state">No report data.</div>`;
  } catch (error) { showToast(error.message, "error"); }
}

async function viewStudent(encodedId) {
  const id = decodeURIComponent(encodedId);
  try {
    const s = (await api(`/api/students/${encodeURIComponent(id)}`)).data;
    $("modal-name").textContent = s.full_name;
    $("modal-content").innerHTML = Object.entries({"Student ID":s.student_id,"Date of Birth":formatDate(s.date_of_birth),"Gender":s.gender,"Email":s.email,"Phone":s.phone_number,"Department":s.department,"Year":s.year,"Section":s.section,"CGPA":s.cgpa,"Attendance":`${s.attendance}%`,"Backlogs":s.backlogs,"Address":s.address}).map(([k,v])=>`<div class="detail-item"><span>${k}</span><strong>${escapeHtml(String(v))}</strong></div>`).join("");
    $("student-modal").classList.remove("hidden");
  } catch (error) { showToast(error.message, "error"); }
}
window.viewStudent = viewStudent;

async function editStudent(encodedId) {
  const id = decodeURIComponent(encodedId);
  try {
    const s = (await api(`/api/students/${encodeURIComponent(id)}`)).data;
    editingStudentId = id;
    $("student-form-title").textContent = "Edit Student";
    $("student-form-subtitle").textContent = `Updating record ${id}.`;
    $("student_id").value=s.student_id; $("student_id").disabled=true; $("full_name").value=s.full_name;
    $("date_of_birth").value=formatDateInput(s.date_of_birth); $("gender").value=s.gender; $("email").value=s.email; $("phone_number").value=s.phone_number;
    await loadDepartmentOptions("department", s.department); $("department").value=s.department;
    $("year").value=s.year; $("section").value=s.section; $("cgpa").value=s.cgpa; $("attendance").value=s.attendance; $("backlogs").value=s.backlogs; $("address").value=s.address;
    $("save-student").textContent="Update Student";
    switchPage("add-student");
  } catch (error) { showToast(error.message, "error"); }
}
window.editStudent = editStudent;

async function deleteStudent(encodedId) {
  const id=decodeURIComponent(encodedId);
  if (!confirm(`Delete student ${id}? This action cannot be undone.`)) return;
  try { await api(`/api/students/${encodeURIComponent(id)}`, {method:"DELETE"}); showToast("Student deleted successfully."); await refreshAllViews(); }
  catch(error){ showToast(error.message,"error"); }
}
window.deleteStudent = deleteStudent;

async function refreshAllViews() {
  await loadDashboard();
  if ($("page-all-students").classList.contains("active-page")) await loadAllStudents();
  if ($("page-departments").classList.contains("active-page")) await loadDepartments();
  if ($("page-reports").classList.contains("active-page")) await loadReports();
}

function getStudentFormData(){return {student_id:$("student_id").value.trim(),full_name:$("full_name").value.trim(),date_of_birth:$("date_of_birth").value,gender:$("gender").value,email:$("email").value.trim(),phone_number:$("phone_number").value.trim(),department:$("department").value,year:Number($("year").value),section:$("section").value.trim(),cgpa:Number($("cgpa").value),address:$("address").value.trim(),attendance:Number($("attendance").value),backlogs:Number($("backlogs").value)}}
async function saveStudent(event){
  event.preventDefault(); const data=getStudentFormData();
  if(!data.department){showToast("Please select a department.","error");return;}
  try{const isEdit=Boolean(editingStudentId);await api(isEdit?`/api/students/${encodeURIComponent(editingStudentId)}`:"/api/students",{method:isEdit?"PUT":"POST",body:JSON.stringify(data)});showToast(isEdit?"Student updated successfully.":"Student added successfully.");resetStudentForm();await refreshAllViews();switchPage("all-students");}catch(error){showToast(error.message,"error")}
}
function resetStudentForm(){editingStudentId=null;$("student-form").reset();$("student_id").disabled=false;$("student-form-title").textContent="Add Student";$("student-form-subtitle").textContent="Create a new academic record.";$("save-student").textContent="Save Student";$("backlogs").value=0;}

async function searchStudents(event){
  event.preventDefault(); const params=new URLSearchParams();
  const values={search:$("search-name").value.trim() || $("search-student-id").value.trim(),department:$("search-department").value,year:$("search-year").value,email:$("search-email").value.trim(),phone:$("search-phone").value.trim()};
  Object.entries(values).forEach(([k,v])=>{if(v)params.set(k,v)}); params.set("limit","100");
  $("search-results").innerHTML=`<div class="loading">Searching...</div>`;
  try{const result=await api(`/api/students?${params}`);$("search-results").innerHTML=`<p class="muted">Found ${result.pagination.total} record(s).</p>`+studentTable(result.data)}catch(error){$("search-results").innerHTML=`<div class="empty-state">${escapeHtml(error.message)}</div>`}
}
function clearSearch(){["search-student-id","search-name","search-email","search-phone"].forEach(id=>$(id).value="");$("search-department").value="";$("search-year").value="";$("search-results").innerHTML=`<div class="empty-state">Enter search criteria to find students.</div>`}

function formatDate(v){return v?new Date(v).toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"}):""}
function formatDateInput(v){return v?String(v).slice(0,10):""}
function escapeHtml(v){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[c]))}
function escapeAttr(v){return escapeHtml(v)}

$("login-form").addEventListener("submit",async e=>{e.preventDefault();$("login-error").textContent="";try{const r=await api("/api/auth/login",{method:"POST",body:JSON.stringify({login:$("login").value.trim(),password:$("password").value})});showApp(r.admin);switchPage("dashboard")}catch(error){$("login-error").textContent=error.message}});
$("logout-btn").addEventListener("click",async()=>{try{await api("/api/auth/logout",{method:"POST"})}finally{showLogin()}});
document.addEventListener("click",e=>{const b=e.target.closest("[data-page]");if(b)switchPage(b.dataset.page)});
["all-search","all-department","all-year","all-section","all-sort","all-order"].forEach(id=>$(id).addEventListener("change",()=>{allPage=1;loadAllStudents()}));
let searchTimer; $("all-search").addEventListener("input",()=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>{allPage=1;loadAllStudents()},300)});
$("reset-all-filters").addEventListener("click",()=>{$("all-search").value="";$("all-department").value="";$("all-year").value="";$("all-section").value="";$("all-sort").value="full_name";$("all-order").value="ASC";allPage=1;loadAllStudents()});
$("clear-department").addEventListener("click",()=>{currentDepartment="";$("selected-department-title").textContent="All Departments";$("selected-department-subtitle").textContent="Select a department card to view its students.";$("department-students-list").innerHTML=`<div class="empty-state">Select a department card above.</div>`});
$("search-form").addEventListener("submit",searchStudents);$("clear-search").addEventListener("click",clearSearch);$("student-form").addEventListener("submit",saveStudent);$("cancel-form").addEventListener("click",()=>{resetStudentForm();switchPage("all-students")});$("refresh-reports").addEventListener("click",loadReports);$("close-modal").addEventListener("click",()=>$("student-modal").classList.add("hidden"));$("student-modal").addEventListener("click",e=>{if(e.target===$("student-modal"))$("student-modal").classList.add("hidden")});$("mobile-menu").addEventListener("click",()=>document.querySelector(".sidebar").classList.toggle("open"));

checkSession();
