-- Student Record Lookup System
-- MySQL 8+
-- One centralized students table. Department is DATA, not separate tables.

CREATE DATABASE IF NOT EXISTS student_record_db;
USE student_record_db;

CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(30) NOT NULL UNIQUE,
    full_name VARCHAR(120) NOT NULL,
    date_of_birth DATE NOT NULL,
    gender ENUM('Male', 'Female', 'Other') NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone_number VARCHAR(20) NOT NULL,
    department VARCHAR(100) NOT NULL,
    year INT NOT NULL,
    section VARCHAR(10) NOT NULL,
    cgpa DECIMAL(4,2) NOT NULL,
    address VARCHAR(255) NOT NULL,
    attendance DECIMAL(5,2) NOT NULL,
    backlogs INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT chk_year CHECK (year BETWEEN 1 AND 4),
    CONSTRAINT chk_cgpa CHECK (cgpa BETWEEN 0 AND 10),
    CONSTRAINT chk_attendance CHECK (attendance BETWEEN 0 AND 100),
    CONSTRAINT chk_backlogs CHECK (backlogs >= 0),
    INDEX idx_students_department (department),
    INDEX idx_students_year (year),
    INDEX idx_students_section (section),
    INDEX idx_students_department_year (department, year)
);

-- If upgrading an older database that already has students but no id column,
-- back up first and run an appropriate migration rather than recreating data.
-- The department field is mandatory and should remain a normal VARCHAR column.

-- Demo login: admin / password
INSERT INTO admins (username, email, password_hash)
VALUES ('admin', 'admin@college.edu', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy')
ON DUPLICATE KEY UPDATE username = username;

INSERT INTO students
(student_id, full_name, date_of_birth, gender, email, phone_number, department, year, section, cgpa, address, attendance, backlogs)
VALUES
('CSE001','Anjali Reddy','2006-04-12','Female','anjali.reddy@college.edu','9876543210','CSE',2,'A',8.75,'Hyderabad, Telangana',92.50,0),
('CSE002','Rahul Kumar','2005-11-21','Male','rahul.kumar@college.edu','9876501234','CSE',3,'B',7.80,'Secunderabad, Telangana',86.00,2),
('CSE003','Priya Sharma','2006-06-18','Female','priya.sharma@college.edu','9876505678','CSE',1,'A',9.05,'Hyderabad, Telangana',95.00,0),
('CSE004','Nikhil Rao','2005-02-13','Male','nikhil.rao@college.edu','9876506789','CSE',4,'C',8.30,'Medchal, Telangana',88.00,1),
('CDS001','Vishalini Rao','2006-03-15','Female','vishalini.rao@college.edu','9988776655','CSE - Data Science',2,'A',9.20,'Hyderabad, Telangana',94.00,0),
('CDS002','Kiran Varma','2005-09-22','Male','kiran.varma@college.edu','9988771122','CSE - Data Science',3,'B',8.45,'Warangal, Telangana',88.50,1),
('CDS003','Sneha Devi','2006-12-02','Female','sneha.devi@college.edu','9988773344','CSE - Data Science',2,'A',9.10,'Nalgonda, Telangana',96.00,0),
('CDS004','Aditya Sai','2005-07-09','Male','aditya.sai@college.edu','9988774455','CSE - Data Science',4,'C',8.65,'Hyderabad, Telangana',90.00,0),
('ECE001','Rohit Rao','2005-05-10','Male','rohit.rao@college.edu','9123456789','ECE',3,'A',8.10,'Hyderabad, Telangana',89.00,1),
('ECE002','Kavya Sri','2006-01-28','Female','kavya.sri@college.edu','9012345678','ECE',1,'C',8.95,'Karimnagar, Telangana',93.00,0),
('ECE003','Harsha Vardhan','2006-08-19','Male','harsha.vardhan@college.edu','9012341111','ECE',2,'B',8.40,'Khammam, Telangana',87.00,0),
('EEE001','Arun Kumar','2005-08-17','Male','arun.kumar@college.edu','9001122334','EEE',4,'A',7.65,'Hyderabad, Telangana',81.50,2),
('EEE002','Divya Lakshmi','2006-03-03','Female','divya.lakshmi@college.edu','9001122445','EEE',2,'B',8.70,'Nalgonda, Telangana',91.00,0),
('ME001','Sai Teja','2006-10-07','Male','sai.teja@college.edu','9112233445','Mechanical',2,'B',8.25,'Suryapet, Telangana',87.00,0),
('ME002','Pavan Kumar','2005-04-29','Male','pavan.kumar@college.edu','9112233556','Mechanical',3,'A',7.95,'Hyderabad, Telangana',84.00,1),
('CIV001','Meghana Lakshmi','2006-02-09','Female','meghana.lakshmi@college.edu','9223344556','Civil',3,'A',8.60,'Nalgonda, Telangana',91.00,0),
('CIV002','Sandeep Reddy','2005-12-11','Male','sandeep.reddy@college.edu','9223344667','Civil',1,'B',7.90,'Hyderabad, Telangana',83.00,1),
('OTH001','Varun Sai','2005-07-19','Male','varun.sai@college.edu','9334455667','Other',4,'B',7.90,'Hyderabad, Telangana',84.00,1),
('OTH002','Keerthana Rao','2006-11-14','Female','keerthana.rao@college.edu','9334455778','Other',2,'A',8.55,'Warangal, Telangana',90.00,0),
('CSE005','Manoj Krishna','2006-09-25','Male','manoj.krishna@college.edu','9445566778','CSE',1,'B',8.15,'Hyderabad, Telangana',88.00,0)
ON DUPLICATE KEY UPDATE student_id = student_id;
